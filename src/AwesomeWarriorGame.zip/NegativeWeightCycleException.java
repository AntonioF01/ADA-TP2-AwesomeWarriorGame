public class NegativeWeightCycleException extends Exception {
    public NegativeWeightCycleException() {
        super("Full of energy");
    }
}